<?php

namespace Drupal\d8_training;

/**
 * Interface ControlServiceDemoInterface.
 *
 * @package Drupal\d8_training
 */
interface ControlServiceDemoInterface {


}
