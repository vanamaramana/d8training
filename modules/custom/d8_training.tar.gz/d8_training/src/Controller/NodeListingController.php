<?php

namespace Drupal\d8_training\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\node\NodeInterface;
use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * Class D8CustomController.
 *
 * @package Drupal\d8_custom\Controller
 */
class NodeListingController extends ControllerBase {
  /**
   * Controller_method_name.
   *
   * @return string
   *   Return Hello string.
   */
  public function content() {
    return [
      '#theme' => 'item_list',
      '#items' => array('one', 'two')
    ];
  }
  
  public function content_entitytype() {
    return [
      '#theme' => 'markup',
      '#markup' => t('Hello '),
    ];
  }

}
