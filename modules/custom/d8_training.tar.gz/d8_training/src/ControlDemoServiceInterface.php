<?php

namespace Drupal\d8_training;

/**
 * Interface ControlDemoServiceInterface.
 *
 * @package Drupal\d8_training
 */
interface ControlDemoServiceInterface {


}
