(function ($) {
  'use strict';

  $(document).ready(function () {
  	alert('hello');
  });
})(jQuery);